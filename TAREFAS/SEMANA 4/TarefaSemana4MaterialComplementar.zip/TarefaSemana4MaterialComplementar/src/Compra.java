
public class Compra {
	protected double valor;

	public Compra(double valor) {
		this.valor = valor;
	}

	public double total() {
		return this.valor;
	}

}
